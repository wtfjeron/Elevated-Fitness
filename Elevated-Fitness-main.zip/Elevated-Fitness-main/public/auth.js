import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
import { 
    getAuth, 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword, 
    signOut, 
    onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";
import { 
    getFirestore, 
    collection, 
    addDoc, 
    getDocs, 
    orderBy, 
    query, 
    deleteDoc, 
    doc 
} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyB3YeX6mjHsPuXO7Gr855rnYfFQ4ra8q0k",
    authDomain: "elevated-fitness-6c0a5.firebaseapp.com",
    projectId: "elevated-fitness-6c0a5",
    storageBucket: "elevated-fitness-6c0a5.firebasestorage.app",
    messagingSenderId: "133961562502",
    appId: "1:133961562502:web:49c2b0b6940c17b990d407",
    measurementId: "G-X18QTSZE1C"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ========== AUTHENTICATION FUNCTIONS ==========

async function signIn(email, password) {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return userCredential.user;
    } catch (error) {
        throw error;
    }
}

async function signUp(email, password) {
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        return userCredential.user;
    } catch (error) {
        throw error;
    }
}

async function logout() {
    try {
        await signOut(auth);
        return true;
    } catch (error) {
        throw error;
    }
}

function getCurrentUser() {
    return auth.currentUser;
}

function onAuthStateChange(callback) {
    return onAuthStateChanged(auth, callback);
}

// ========== REVIEW FUNCTIONS (SAVE TO FIRESTORE) ==========

// Save a review to Firestore
async function saveReview(productId, reviewText, rating, reviewerName) {
    try {
        const user = auth.currentUser;
        if (!user) {
            throw new Error("You must be logged in to leave a review");
        }

        const reviewsRef = collection(db, "reviews");
        const newReview = {
            productId: productId.toString(),
            text: reviewText,
            rating: parseInt(rating),
            reviewer: reviewerName || user.email || "Anonymous",
            userId: user.uid,
            userEmail: user.email,
            createdAt: new Date().toISOString()
        };

        const docRef = await addDoc(reviewsRef, newReview);
        console.log("Review saved with ID:", docRef.id);
        return docRef.id;
    } catch (error) {
        console.error("Error saving review:", error);
        throw error;
    }
}

// Get all reviews from Firestore
async function getAllReviews() {
    try {
        const reviewsRef = collection(db, "reviews");
        const q = query(reviewsRef, orderBy("createdAt", "desc"));
        const querySnapshot = await getDocs(q);
        
        const reviews = [];
        querySnapshot.forEach((doc) => {
            reviews.push({
                id: doc.id,
                ...doc.data()
            });
        });
        return reviews;
    } catch (error) {
        console.error("Error getting reviews:", error);
        return [];
    }
}

// Delete a review (only if user owns it)
async function deleteReview(reviewId) {
    try {
        const user = auth.currentUser;
        if (!user) {
            throw new Error("You must be logged in to delete a review");
        }
        
        const reviewRef = doc(db, "reviews", reviewId);
        await deleteDoc(reviewRef);
        console.log("Review deleted successfully");
        return true;
    } catch (error) {
        console.error("Error deleting review:", error);
        throw error;
    }
}

export { 
    signIn, 
    signUp, 
    logout, 
    getCurrentUser, 
    onAuthStateChange,
    saveReview,
    getAllReviews,
    deleteReview,
    auth,
    db
};